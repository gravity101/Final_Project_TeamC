#!/usr/bin/env python
# -*- coding: utf-8 -*-

import cv2
import rospy
import numpy as np
from xycar_motor.msg import xycar_motor
from stanley.stanley_follower import StanleyController
from traffic_sign.TrafficSignDetetector import TrafficSignDetetector

class Xycar(object):

    def __init__(self) :
        self.rate = rospy.Rate(10)
        self.pub = rospy.Publisher('xycar_motor', xycar_motor, queue_size=1)
        self.msg = xycar_motor()
        self.stanley_follower = StanleyController()
        self.traffic_check = TrafficSignDetetector()
        self.traffic_sign = ""
    
    def control(self) :
        self.stanley_follower.Control()
        self.traffic_sign = self.traffic_check.Detect()
        self.msg.speed = self.stanley_follower.speed
        self.msg.angle = self.stanley_follower.angle
        self.pub.publish(self.msg)
        self.rate.sleep()